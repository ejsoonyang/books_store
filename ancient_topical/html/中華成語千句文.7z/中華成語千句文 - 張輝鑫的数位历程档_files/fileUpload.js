/**
 * Created by JCloudYu on 2/20/14.
 */
(function ($, window) {

	// INFO: Prepare singleton variables
	var uploadZone =
		$("<div id='jq-file-upload-window'  class='disableZone' style='display:none'>" +
			"<div class='window-file-status'>" +
				"<div class='clearfix col-title'>" +
					"<div class='file-path'>" + gRes.filename + "</div>" +
					"<div class='file-size'>" + gRes.filesize + "</div>" +
					"<div class='file-status'>" + gRes.progress + "</div>" +
					"<div class='upload-status'>" + gRes.status + "</div>" +
				"</div>" +
				"<ul class='file-list'>" +

				"</ul>" +
				"<div style='text-align:center; margin-top:5px;'>" +
					"<button role='close'>" + gRes.close + "</button>" +
				"</div>" +
			"</div>" +
		"</div>"),

		fWindow = uploadZone.find('.window-file-status'),
		fList = uploadZone.find('.file-list');




	// INFO: Prepare intermediate variables and functions
	var fileCounter = 0,
		fileBaseName = randString(),

		clearList = function() {
			fWindow.removeClass('done');
			fList.empty();
		},
		show = function() {
			uploadZone.show();
		},
		hide = function() {
			uploadZone.hide();
			clearList();
		};




	// INFO: Prepare global API provider
	function uploadFactory() {

		return {
			show: function() { show(); return this; },
			hide: function() { hide(); return this; },
			addTracker: function(fileInfo) {

				var fileId = fileBaseName + (++fileCounter);

				fList.append(
					$("<li id='" + fileId + "' class='clearfix'>" +
						"<div class='upload-info clearfix'>" +
							"<div class='file-path'>" + fileInfo.name + "</div>" +
							"<div class='file-size'>" + size(fileInfo.size) + "</div>" +
							"<div class='progress file-status'>" +
								"<div class='bar' style='width:0;' role='progress'></div>" +
								"<div class='file-upload-hint'>" + gRes.wait + "</div>" +
							"</div>" +
							"<div class='upload-status'>" + gRes.status2 + "</div>" +
						"</div>" +
						"<div class='detail-status'></div>" +
					"</li>")
				);

				return fileId;
			},
			updateTracker: function(trackerId, dataProgress, options) {

				options = options || {};

				options.state	  = options.state		|| 'normal';
				options.statusTag = options.statusTag	|| gRes.status2;
				options.statusMsg = options.statusMsg	|| '';

				var currentProgress = Math.floor(dataProgress.loaded / dataProgress.total * 100.0);
				var item = fList.find('#' + trackerId + ' [role="progress"]');
				item.css('width', currentProgress + '%');
				fList.find(".file-upload-hint").remove();




				if (options.state == 'error')
					item.addClass('bar-danger');
				else
				if (options.state == 'success')
					item.addClass('bar-success');
				else
					item.removeClass('bar-danger').removeClass('bar-success');




				item = fList.find('#' + trackerId + ' .upload-status').text(options.statusTag);
				if (options.state == 'error')
					item.addClass('error');
				else
					item.removeClass('error');




				item = fList.find('#' + trackerId + ' .detail-status').text(options.statusMsg);
				if (options.state == 'error')
					item.addClass('error');
				else
					item.removeClass('error');

				return this;
			},
			done: function() {
				fWindow.addClass('done');
				return this;
			}
		};
	}




	// INFO: Initialization
	$(document).ready(function() {

		$('body').append(uploadZone);

		uploadZone.scroll(function(e) {
			e.stopPropagation();
			e.preventDefault();
		});

		uploadZone.find('button[role="close"]').click(function(e) {
			e.preventDefault();
			hide();

			$('#jq-file-upload-window').trigger("windowClosed");
		});

		// INFO: Register API to global scope
		window.uploadWindow = uploadFactory;
	});




	// INFO: Supportive functions
	function randString(len, charSet)
	{
		len = len || 5;
		charSet = charSet || 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';

		var str = '';
		for (var i = 0; i < len; i++) {
			var randomPoz = Math.floor(Math.random() * charSet.length);
			str += charSet.substring(randomPoz, randomPoz + 1);
		}

		return str;
	}


	function toFixed(value, precision) {
		var precision = precision || 0,
			neg = value < 0,
			power = Math.pow(10, precision),
			value = Math.round(value * power),
			integral = String((neg ? Math.ceil : Math.floor)(value / power)),
			fraction = String((neg ? -value : value) % power),
			padding = new Array(Math.max(precision - fraction.length, 0) + 1).join('0');

		return precision ? integral + '.' +  padding + fraction : integral;
	}


	function size(byte)
	{
		var size = Number(byte),
			unit = 'B';

		if (isNaN(size)) {
			return '';
		}

		if (size >= 1024.0)
		{
			size /= 1024.0;
			unit = 'KB'
		}

		if (size >= 1024.0)
		{
			size /= 1024.0;
			unit = 'MB';
		}

		if (size >= 1024.0)
		{
			size /= 1024.0;
			unit = 'GB';
		}

		if (size >= 1024.0)
		{
			size /= 1024.0;
			unit = 'TB';
		}

		size = toFixed(size, 2);

		return size.valueOf() + ' ' + unit;
	}

})(jQuery, window);
