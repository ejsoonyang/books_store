/*if (top.location != location) {
  top.location.href = document.location.href;
}*/


var ids=new Array();
var hidecoex = false;

var ex;

document.getElementsByClassName = function(cl) {
var retnode = [];
var myclass = new RegExp('\\b'+cl+'\\b');
var elem = this.getElementsByTagName('*');
for (var i = 0; i < elem.length; i++) {
var classes = elem[i].className;
if (myclass.test(classes)) retnode.push(elem[i]);
}
return retnode;
}; 


function QAinit(){
if(document.getElementById){
var tids=document.getElementsByClassName('sprite-expand'); // getElementsByTagName('img');

for(i=0;i<tids.length;i++) tids[i].onmouseup=setstate;

tids=document.getElementsByClassName('sprite-unexpand'); // getElementsByTagName('img');
for(i=0;i<tids.length;i++) tids[i].onmouseup=setstate;
}
}

/*function QAinit(){
if(document.getElementById){
var tids=document.getElementsByClassName('subtitle'); // getElementsByTagName('img');
for(i=0;i<tids.length;i++)if(tids[i].className=="subtitle")ids[ids.length]=tids[i];
for(i=0;i<ids.length;i++)ids[i].onmouseup=setstate;
}}
*/

function setstate(){
// for(i=0;i<ids.length;i++){
//  if(ids[i]==this){
//alert(this.getAttribute('class'));
   var d=this.parentNode.parentNode.getElementsByTagName('span')[0];
   var i=this;
   if(d) {
   if(d.style.display=="inline") {
    d.style.display="none";
    this.setAttribute('className','sprite-expand');
    this.setAttribute('class','sprite-expand');
    //i.src = "expand.png";
   } else {
    d.style.display="inline";
    this.setAttribute('className','sprite-unexpand');
    this.setAttribute('class','sprite-unexpand');
    //i.src = "unexpand.png";
   }
  }
//  }
// }
}
/*
function setstate(){
 for(i=0;i<ids.length;i++){
  if(ids[i]==this){
   var d=this.parentNode.getElementsByTagName('span')[0];
   var i=this.parentNode.getElementsByTagName('img')[0];
   if(d.style.display=="inline") {
    d.style.display="none";
    i.src = "expand.png";
   } else {
    d.style.display="inline";
    i.src = "unexpand.png";
   }
  }
 }
}*/

function expandall(){
if(document.getElementById){
for(i=0;i<ids.length;i++)ids[i].parentNode.getElementsByTagName('span')[1].style.display="block";
}}

function collapseall(){
if(document.getElementById){
for(i=0;i<ids.length;i++)ids[i].parentNode.getElementsByTagName('span')[1].style.display="none";
}}

function removelink() {
  if(document.getElementById('linkres')) {
    document.getElementById('linkres').value = '';
  }
  if(document.getElementById('linkrow')) {
    document.getElementById('linkrow').style.display = 'none';
  }
}


function updatedictionary(book, offset) {
  var node = document.getElementById("dic" + offset).value;
  var url = "update.pl?data=dictionary," + book + "," + offset + "," + node; 
//alert(url);
//return;
  request.open("GET", url, true);
  request.onreadystatechange = updatePage;
  request.send(null);
}

   function updatePage() {
     if (request.readyState == 4) {
       if (request.status == 200) {
var response = request.responseText;
if(response != 'OK') {
  alert(response);
}
       }
     }
   }


var request = false;
try {
  request = new XMLHttpRequest();
} catch (trymicrosoft) {
  try {
    request = new ActiveXObject("Msxml2.XMLHTTP");
  } catch (othermicrosoft) {
    try {
      request = new ActiveXObject("Microsoft.XMLHTTP");
    } catch (failed) {
      request = false;
    }
  }
}

if (!request)
  alert("Error initializing XMLHttpRequest!");


var depthreq = 1;
var namereq = '';
var showsub = 0;

   function getData(name, depth) {
     namereq = name;
     var node = document.getElementById("l" + name + depth).value;
    document.getElementById(name).value = node;
    if(node == '' || node == 0) {
       document.getElementById("s" + name + (depth+1)).innerHTML = '';
     } else {
       var iflang = document.getElementById("if").value;
       var url = "nav.pl?node=" + node + "&if=" + iflang + "&sub=" + showsub + "&name=" + name;
       depthreq = depth;
       request.open("GET", url, true);
       request.onreadystatechange = updatePage;
       request.send(null);
     }
   }

   function updatePage() {
    if (request.readyState == 4) {
       if (request.status == 200) {
         if(request.responseText.charAt(0) == "0") {
           /*document.getElementById("orig").innerHTML =  '<p>' + request.responseText.substring(1) + '</p>';*/
         } else {
             /*document.getElementById("orig").innerHTML = '';*/
           if(request.responseText != '') {
             var alltext = "All";
             if(document.getElementById("if").value == 'gb') {alltext = "全部";}
             document.getElementById("s"+namereq + (depthreq+1)).innerHTML =  '<select id="l'+namereq + (depthreq+1) + '" class="booklistbox" onChange="getData(\''+namereq +'\',' + (depthreq+1) + ');"><option value="">[' + alltext + ']</option>' + request.responseText + '</select><span id="s' + namereq+ (depthreq+2) + '"></span>';
/*alert(document.getElementById("s"+namereq + (depthreq+1)).innerHTML);*/
           }
         }
       } //else
         //alert("status is " + request.status);
     }
   }

function addSearch(depth) {
           document.getElementById("param"+depth).innerHTML =  '<br /><input type="text" name="search' + depth + '" id="search' + depth + '" size="20" class="searchbox" /><input type="radio" name="textonly' + depth + '" id="textonly' + depth + '" value="textonly" checked="checked" onclick="hideSemantics(' + depth + ');" />Text search<input type="radio" name="textonly' + depth + '" value="semantic"  onclick="matchword(' + depth + ');" />Dictionary match<span id="semantic' + (depth) + '"></span><br /><span id="param' + (depth+1) + '" name="param' + (depth+1) + '"><input type="submit" value="More..." onclick="addSearch(' + (depth+1) + ');" /></span>';
}

function matchword(depth, hide) {
  if(hide) {
    hidecoex = true;
  }
     var node = document.getElementById("search" + depth).value;
     if(node == '') {
       alert('Please enter the word or character you wish to search on.\n請先輸入您想要查詢的字詞。');
       document.getElementById("textonly"+depth).checked = "checked";

       return false;
     } else {
       var url = "dic.pl?char=" + escape(node) + "&if=en"; 
       depthreq = depth;
       request.open("GET", url, true);
       request.onreadystatechange = showSemantics;
       request.send(null);
     }
}

function findResource() {
     var node = document.getElementById("searchres").value;
     document.getElementById("resourcechoice").innerHTML = '';
     if(node == '') {
       alert('Please enter the surname of an author or a word in the title to search on.\n請先輸入作者姓名或書名的關鍵詞。');
       return false;
     } else {
       var url = "res.pl?search=" + escape(node) + "&if=en";
       request.open("GET", url, true);
       request.onreadystatechange = showResources;
       request.send(null);
     }
  return false;
}
function showResources() {
    if (request.readyState == 4) {
       if (request.status == 200) {
         if(request.responseText.charAt(0) == "0") {
           alert('No matching entries found.');
         } else {
             document.getElementById("resourcechoice").innerHTML =  '<select name="resource" id="resource">' + request.responseText + '</select><input type="submit" value="Add" />';
         }
       } //else
         //alert("status is " + request.status);
     }
}

   function showSemantics() {
    if (request.readyState == 4) {
       if (request.status == 200) {
         if(request.responseText.charAt(0) == "0") {
           alert('No matching entries in the CTP dictionary.');
           document.getElementById("textonly"+depthreq).checked = "checked";

           /*document.getElementById("semantic"+depthreq).innerHTML =  request.responseText.substring(1);*/
         } else {
           if(hidecoex) {
             document.getElementById("semantic"+depthreq).innerHTML =  '<select name="semanticchoice' + depthreq + '" id="semanticchoice' + depthreq + '">' + request.responseText + '</select>';
           } else {
             document.getElementById("semantic"+depthreq).innerHTML =  '<select id="semanticchoice' + depthreq + '">' + request.responseText + '</select><br /><input type="checkbox" id="filterc' + depthreq + '" value="yes" />Include coextensive terms';
           }
         }
       } //else
         //alert("status is " + request.status);
     }
   }
function hideSemantics(depth) {
  document.getElementById("semantic"+depth).innerHTML =  "";

}

function noSemantics(depth) {
  document.getElementById("textonly"+depth).checked = "checked";

}

function enableParallel() {
  if(document.getElementById("enableparallel").checked) {
    document.getElementById("lparallelsearch1").disabled = '';
    document.getElementById("lparallelsearch2").disabled = '';
  } else {
    document.getElementById("sparallelsearch3").innerHTML = '';
    document.getElementById("lparallelsearch1").options[0].selected = true;
    document.getElementById("lparallelsearch1").disabled = 'disabled';
    document.getElementById("lparallelsearch2").options[0].selected = true;
    document.getElementById("lparallelsearch2").disabled = 'disabled';
  }
}


function prepareSearch() {
document.getElementById("node").value = 3925;
  var i;
for(i=1;i<10;i++) {
    var thisCntrl = document.getElementById("lnode"+i);
    if(thisCntrl) {
     if(thisCntrl.options[thisCntrl.selectedIndex].value) {
      document.getElementById("node").value = thisCntrl.options[thisCntrl.selectedIndex].value;
     }
    }
  }
if(!document.getElementById("node").value) {
  document.getElementById("node").value = 3925;
}
if(!document.getElementById("parallelsearch").value) {
  document.getElementById("parallelsearch").value = 3925;
}
for(i=1;i<10;i++) {
    var thisCntrl = document.getElementById("lparallelsearch"+i);
    if(thisCntrl) {
     if(thisCntrl.options[thisCntrl.selectedIndex].value) {
      document.getElementById("parallelsearch").value = thisCntrl.options[thisCntrl.selectedIndex].value;
     }
    }
  }

if(!document.getElementById("enableparallel").checked) {
  document.getElementById("parallelsearch").value = '';
}

  var searchstring = '';
  var filterstring = '';
  for(i=1;i<10;i++) {

   if(document.getElementById("textonly" + i)) {
    if(document.getElementById("textonly" + i).checked) {
     if(document.getElementById("search" + i).value != '') {
      if(searchstring != '') {
        searchstring = searchstring + " ";
      }
      if(document.getElementById("search" + i).value.indexOf(" ")>-1) {
        searchstring = searchstring + '"' + document.getElementById("search" + i).value + '"';
      } else {
        searchstring = searchstring + document.getElementById("search" + i).value;
      }
     }
    } else {
      var ind = document.getElementById("semanticchoice" + i).selectedIndex;
      if(filterstring != '') {
        filterstring = filterstring + ",";
      }
      filterstring = filterstring + 'd' + document.getElementById("semanticchoice" + i).options[ind].value;
      if(document.getElementById("filterc" + i).checked!= '') {
         filterstring = filterstring + "c";
      }
    }
   }
  }
  if(sellist) {
    for(i=0;i<sellist.length;i++) {
      if(filterstring != '') {
        filterstring = filterstring + ",";
      }
      filterstring = filterstring + "p" + sellist[i];
    }
  }

  document.getElementById("filter").value = filterstring;
  document.getElementById("searchu").value = searchstring;
  document.getElementById("yearfrom").value = document.getElementById("yearfrom1").value;
  document.getElementById("yearto").value = document.getElementById("yearto1").value;
  if(document.getElementById("reqtype1").checked) {
    document.getElementById("reqtype").value = 'stats';
  } else {
    document.getElementById("reqtype").value = '';
  }
  if(document.getElementById("matchtype1").checked) {
    document.getElementById("matchtype").value = 'exact';
  } else if(document.getElementById("matchtype2").checked) {
    document.getElementById("matchtype").value = 'binary';
  } else {
    document.getElementById("matchtype").value = '';
  }

  var propsearch = "";
  var propsearchterms = 0;
  for(i=0;i<sellist.length;i++) {
   var thisterm = document.getElementById("propsearch"+sellist[i]).value;
   propsearch = propsearch + thisterm + "|";
   if(thisterm) {
     propsearchterms++;
   }
  }
  if(propsearchterms==0) {
    propsearch = "";
  }
  document.getElementById("ps").value = propsearch;
  return true;

}

function vote(message, voteval) {
  var url = "vote.pl?message=" + message + "&vote=" + voteval; 
  request.open("GET", url, true);
/*  request.onreadystatechange = showSemantics;*/
  request.send(null);
  if(document.getElementById("vote"+message)) {
    document.getElementById("vote"+message).style.display = 'none';
  }
}

function setActiveStyleSheetSafari(title) {
  var i, cacheobj, altsheets=[""];
  if(setActiveStyleSheetSafari.chosen)
    try{
      document.getElementsByTagName('head')[0].removeChild(setActiveStyleSheetSafari.chosen);
    }catch(e){}
  for(i=0; (cacheobj=document.getElementsByTagName("link")[i]); i++) {
    if(cacheobj.getAttribute("rel").toLowerCase()=="alternate stylesheet" && cacheobj.getAttribute("title")) { //if this is an alternate stylesheet with title
      cacheobj.disabled = true
      altsheets.push(cacheobj) //store reference to alt stylesheets inside array
      if(cacheobj.getAttribute("title") == title){ //enable alternate stylesheet with title that matches parameter
        cacheobj.disabled = false //enable chosen style sheet
        setActiveStyleSheetSafari.chosen = document.createElement('link');//cloneNode(false);
        setActiveStyleSheetSafari.chosen.rel = 'stylesheet';
        setActiveStyleSheetSafari.chosen.type = 'text/css';
        if(cacheobj.media)
          setActiveStyleSheetSafari.chosen.media = cacheobj.media;
        setActiveStyleSheetSafari.chosen.href = cacheobj.href;
        document.getElementsByTagName('head')[0].appendChild(setActiveStyleSheetSafari.chosen);
      }
    }
  }
}

function setActiveStyleSheet(title) {
  var i, a, main;
  for(i=0; (a = document.getElementsByTagName("link")[i]); i++) {
    if(a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title")) {
      a.disabled = true;
      if(a.getAttribute("title") == title) a.disabled = false;
    }
  }
  var metatags = document.getElementsByTagName("meta");
  var newviewport = "width=1024, initial-scale=0.5, maximum-scale=1.0, user-scalable=yes";
  if(title == 'Compact')
    newviewport = "width=device-width, target-densitydpi=device-dpi, initial-scale=1.0, maximum-scale=1.0";
  for(cnt=0;cnt<metatags.length;cnt++)
  {
    var name = metatags[cnt].getAttribute("name");
    if (metatags[cnt].getAttribute("name") == "viewport"){
      metatags[cnt].setAttribute("content", newviewport);
    }
  }
}

if(navigator.userAgent.lastIndexOf('Safari/') > 0) {
  setActiveStyleSheet = setActiveStyleSheetSafari
}


function getActiveStyleSheet() {
  var i, a;
  for(i=0; (a = document.getElementsByTagName("link")[i]); i++) {
    if(a.getAttribute("rel").indexOf("style") != -1 && a.getAttribute("title") && !a.disabled) return a.getAttribute("title");
  }
  return null;
}

function getPreferredStyleSheet() {
  var i, a;
  for(i=0; (a = document.getElementsByTagName("link")[i]); i++) {
    if(a.getAttribute("rel").indexOf("style") != -1
       && a.getAttribute("rel").indexOf("alt") == -1
       && a.getAttribute("title")
       ) return a.getAttribute("title");
  }
  return null;
}

function createCookie(name,value,days) {
  if (days) {
    var date = new Date();
    date.setTime(date.getTime()+(days*24*60*60*1000));
    var expires = "; expires="+date.toGMTString();
  }
  else expires = "";
  document.cookie = name+"="+value+expires+"; path=/";
}

function readCookie(name) {
  var nameEQ = name + "=";
  var ca = document.cookie.split(';');
  for(var i=0;i < ca.length;i++) {
    var c = ca[i];
    while (c.charAt(0)==' ') c = c.substring(1,c.length);
    if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
  }
  return null;
}

window.onload = function(e) {
  var cookie = readCookie("style");
  var title = cookie ? cookie : getPreferredStyleSheet();
  if(!cookie && screen.width<800)
    title = 'Compact';
  setActiveStyleSheet(title);
  QAinit(e);

  var target=decodeURIComponent(location.hash.substring(1));
  if(target.charCodeAt(0)>255) {
    var chars = target.length;
//alert(target.length);
    var start;
    var matched = 0;
    for(start=1;start<500;start++) {
      var thischar = document.getElementById('c'+start).innerHTML;
      if(!thischar) {
        start=500;
        continue;
      }
      var match=matchtext(target, start, chars);
//alert("Trying "+target+","+start+","+chars+"...");
//return;
      if(match>0 || (match==-1 && !matched)) {
        matched++;
        if(match==-1) {
          match = target.length;
        }
//alert(match);
        for(check=start;check<start+match;check++) {
          var thischar = document.getElementById('c'+check);
          if(thischar) {
            thischar.style.color='#FF0000';
            thischar.style.fontWeight = 'bold';
          }
        }
      }
    }
  }

  initPopups();
}

function matchtext(sometext, start, chars)
{
  var check;
  var skipped = 0;
  var surrogates = 0;
  for(check=start;check<start+chars+skipped;check++) {
    thischar = document.getElementById('c'+check);
    if(!thischar) {
      return -1; // Crossed end of page
    }
    if(thischar.textContent.substr(0,1) == '　') {
      skipped++;
      continue;
    }
    if(thischar.textContent.substr(0,1) != sometext.substr(check-start-skipped, 1)) {
      return 0;
    }
    if(thischar.textContent.substr(0,2) != thischar.textContent.substr(0,1) && thischar.textContent.substr(0,2) == sometext.substr(check-start-skipped, 2)) {
//alert('matched surrogate');
      //check++;
      skipped--;
      surrogates++;
      chars--;
    }
  }
  return chars+skipped+surrogates;
}
function getText(node) {
    if (node.nodeType === 3) {
        return node.data;
    }

    var txt = '';

    if (node = node.firstChild) do {
        txt += getText(node);
    } while (node = node.nextSibling);

    return txt;

}

window.onunload = function(e) {
  var title = getActiveStyleSheet();
  createCookie("style", title, 365);
}

var cookie = readCookie("style");
var title = cookie ? cookie : getPreferredStyleSheet();
setActiveStyleSheet(title);



function getElementsByClass( searchClass, domNode, tagNames) {
	if (domNode == null) domNode = document;
	if (tagNames == null) tagNames = '*';
	var el = new Array();
	var tags = domNode.getElementsByTagName(tagNames);
	var tcl = " "+searchClass+" ";
	for(i=0,j=0; i<tags.length; i++) {
		var test = " " + tags[i].className + " ";
		if (test.indexOf(tcl) != -1)
			el[j++] = tags[i];
	}
	return el;
}

function initPopups() {
  var links = getElementsByClass('tn', document, 'a');
  var n, i;
  var hiddentable = 0;
  if(document.getElementById('dictable')) {
    hiddentable = document.getElementById('dictable').style.display == 'none';
  }

  for(n=0;n<links.length;n++) {	
    var popupcontent = links[n].getElementsByTagName('span')[0];
    var idnum = links[n].href.substr(links[n].href.indexOf('#')+1,20); // 10
    var desc = "";
    var source = document.getElementsByName(idnum);
    for(i=0;i<source.length;i++) {
      if(source[i].parentNode.parentNode.cells) {
       if(desc.indexOf(source[i].parentNode.parentNode.cells[3].innerHTML)==-1) {
        if(hiddentable && desc == '') {
//desc=desc+links[n].href+' =><br/>'+source[i].parentNode.parentNode.cells[0].childNodes[0].href + "<br />";
//document.getElementById("testoutput").innerHTML=document.getElementById("testoutput").innerHTML+links[n].href+' => '+idnum+'<br/>';
          links[n].href=source[i].parentNode.parentNode.cells[0].childNodes[0].href;
        }
        if(desc != "") {
          desc = desc + "<br />";
        }
        desc = desc + "<b>" + source[i].parentNode.parentNode.cells[3].innerHTML + "</b>";
        if(source[i].parentNode.parentNode.cells[4].innerHTML) {
         desc = desc + "<br />" + source[i].parentNode.parentNode.cells[4].innerHTML;
        }
       }
      }
    }
    var newdiv = document.createElement("div");
    newdiv.innerHTML = desc;
    if(popupcontent) {
      if(document.getElementById('translationtable')) {
        popupcontent.style.marginRight='-400px';
      }
      popupcontent.appendChild(newdiv);
    }
  }
}

function cite (title, url, author, editor) {
  window.open ("/cite.pl?title="+title+"&url="+url+"&author="+author+"&editor="+editor,"","menubar=1,resizable=1,width=700,height=400");
}
var lasthoverid;


function showRefs() {
  var targetdiv = document.getElementById("metaviewer");
  var targettext = "";
  for (var i=0; i<arguments.length; i++) {
    targettext += document.getElementById("meta"+arguments[i]).innerHTML + '<br />';
  }
  targetdiv.innerHTML = targettext;
}

function showParallels(id, event) {
  if(lasthoverid == id) {
    return;
  }
  lasthoverid = id;
  var targetdiv = document.getElementById("metaviewer");
  var targettext = "";

  if(!(typeof jump === 'undefined')) {
   if(jump[id]<0) {
    hideMeta();
    return;
   }
  }

  var j;
  var i = id;

  var best = -1;
  var furthest = -1;
  for(j=0;j<ex.length;j++) {
    if(ex[j][1]<=i && ex[j][1]+ex[j][2]>=i) {
      if(ex[j][1]>furthest || 1) {
        best = j;
        furthest = ex[j][1];
      }
    }
  }
targetdiv.innerHTML = "";

id=best;
var tabl = document.getElementById('pg'+id);
var l = tabl.rows.length;
//alert( 'Number of table rows: ' + l );
var s = '';
for ( var i = 0; i < l && i<10; i++ )
{
  var tr = tabl.rows[i];
  var Cells = tr.getElementsByTagName("td");
  if(tr.className != 'resrowtarget') {
    targetdiv.innerHTML = targetdiv.innerHTML+ (Cells[0].textContent ? Cells[0].textContent : Cells[0].innerText) +"<br />";
//alert(Cells[0].textContent);
  }
}

targetdiv.innerHTML = targetdiv.innerHTML.replace(/:/g,""); 
//targetdiv.innerHTML = 'Number of table rows: ' + l;

  document.getElementById('metaviewer').style.display = 'inline';
  document.getElementById('metaviewer').style.left = mouseX(event) - 100 + 'px';
  document.getElementById('metaviewer').style.top = mouseY(event) + 60 + 'px'; 

}
function jumpParallel(id) {
  var j;
  var i = id.getAttribute('id');

  var best = -1;
  var furthest = -1;
  for(j=0;j<ex.length;j++) {
    if(ex[j][1]<=i && ex[j][1]+ex[j][2]>=i) {
      if(ex[j][1]>furthest || 1) {
        best = j;
        furthest = ex[j][1];
      }
    }
  }

  window.location.hash = "pl"+ex[best][0];
  updateGraph(ex[best][0]);
}

function hideMeta() {
  document.getElementById('metaviewer').style.display = 'none';
  lasthoverid = '';
}





var segmentcolour = new Array();

function highlightSegment(tgt, event) {
  if(lasthoverid == tgt) {
    return;
  }
  lasthoverid = tgt;
  var target = document.getElementById(arguments[0]);
  segmentcolour[tgt]=target.style.backgroundColor;
//alert(target.style.backgroundColor);
  target.style.background='#FF8888';
//  target.style.border='1px solid red';
  target.style.margin='0';
  document.getElementById('metaviewer').style.display = 'inline';
  document.getElementById('metaviewer').style.left = mouseX(event) - 100 + 'px';
  document.getElementById('metaviewer').style.top = mouseY(event) + 60 + 'px'; 

//  target.childNodes[0].style.display = 'inline';
//  target.childNodes[0].innerHTML = document.getElementById("metaviewer").innerHTML;
}

function unhighlightSegment() {
  lasthoverid = '';
  var target = document.getElementById(arguments[0]);
//  target.style.border='';

  target.style.background=segmentcolour[arguments[0]];
//  target.style.margin='1px';
  document.getElementById('metaviewer').style.display = 'none';
//  target.childNodes[0].innerHTML = '';
}

function mouseX(evt) {
if (evt.pageX) return evt.pageX;
else if (evt.clientX)
   return evt.clientX + (document.documentElement.scrollLeft ?
   document.documentElement.scrollLeft :
   document.body.scrollLeft);
else return null;
}
function mouseY(evt) {
if (evt.pageY) return evt.pageY;
else if (evt.clientY)
   return evt.clientY + (document.documentElement.scrollTop ?
   document.documentElement.scrollTop :
   document.body.scrollTop);
else return null;
}

function updateAccepted()
{
  if(request.readyState == 4) {
    if(request.status == 200) {
      var response = request.responseText;
//      if(response != 'OK') {
          var bits = response.split('|');
          document.getElementById('accept'+bits[0]).innerHTML = bits[1];
//        alert(response);
//      }
    }
  }
}

function acceptProperty(propid, accept) {
  var url = "propaccept.pl";
  request.open("POST", url, true);
  request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
  request.onreadystatechange = updateAccepted;
  var iflang = document.getElementById("if").value;
  request.send("id=" + propid + "&accept=" + accept + "&if=" + iflang);
}




function updatePublic()
{
  if(request.readyState == 4) {
    if(request.status == 200) {
      var response = request.responseText;
        var bits = response.split('|');
        if(bits[1] == '0') {
          document.getElementById('pub'+bits[0]).innerHTML = bits[2];
        } else {
          alert(bits[1]);
      }
    }
  }
}
function setPublic(propid, setpub) {
  var url = "proppublic.pl";
  request.open("POST", url, true);
  request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
  request.onreadystatechange = updatePublic;
  var iflang = document.getElementById("if").value;
  request.send("id=" + propid + "&public=" + setpub + "&if=" + iflang);
}

var detailid = "";
var commentaryid = "";

function getPropDetails(propid, target, node) {
  detailid = 'info'+target;
  var existing = document.getElementById(detailid);
  if(existing) {
    if(existing.style.display == '') {
      existing.style.display = 'none';
    } else {
      existing.style.display = '';
    }
  } else {
    var newel = document.createElement('div');
    newel.setAttribute('id', 'info'+target);
    newel.style.marginLeft = '20px';
    newel.style.color = '#000000';
    node.parentNode.parentNode.appendChild(newel); 
    var url = "propinfo.pl?prop=" + propid + "&if="+document.getElementById('if').value; 
    if(document.getElementById('remap')) { url = url + "&remap="+document.getElementById('remap').value; }
    request.open("GET", url, true);
    request.onreadystatechange = showPropDetails;
    request.send(null);
  }
  return false;
}
function showPropDetails()
{
  if(request.readyState == 4) {
    if(request.status == 200) {
      var response = request.responseText;
      if(response.charAt(0) == '0') {
        alert(response.substring(1));
      } else {
        document.getElementById(detailid).innerHTML = response.substring(1);
//alert(document.getElementById(detailid).innerHTML);
      }
    }
  }
}





function getCommentary(node) {
  commentaryid = 'comm'+node;
  var existing = (document.getElementById(commentaryid));
  if(existing.innerHTML != '') {
    if(existing.style.display == '') {
      existing.style.display = 'none';
    } else {
      existing.style.display = '';
    }
  } else {
/*    var newel = document.createElement('div');
    newel.setAttribute('id', 'comm'+node);
    newel.style.marginLeft = '20px';
    newel.style.color = '#000000';
    document.getElementById('comm'+node).appendChild(newel); 
*/
    var url = "commentary.pl?node=" + node + "&if="+document.getElementById('if').value; 
    if(document.getElementById('remap')) { url = url + "&remap="+document.getElementById('remap').value; }
    request.open("GET", url, true);
    request.onreadystatechange = showCommentary;
    request.send(null);
  }
}
function showCommentary()
{
  if(request.readyState == 4) {
    if(request.status == 200) {
      var response = request.responseText;
      if(response.charAt(0) == '0') {
        alert(response.substring(1));
      } else {
        document.getElementById(commentaryid).innerHTML = response.substring(1);
      }
    }
  }
}

function showpgorig(e) {
//alert('test');
	if (!e) var e = window.event;
	var relTarg = e.relatedTarget || e.fromElement;
	var tg = (window.event) ? e.srcElement : e.target;
//	if (tg.nodeName != 'TABLE') return;
	var reltg = tg;//(e.relatedTarget) ? e.relatedTarget : e.toElement;
//alert ("from: "+tg.nodeName+" to: "+reltg.nodeName);
if(reltg) {
	while (reltg && reltg.nodeName != 'BODY')
        {
	  if (reltg.id.substring(0,2)== 'pg') return true;
	  reltg= reltg.parentNode
        }
}
  var i;
    for(i=0;i<wts.length;i++) {
      for(j=0;j<wts[i].length;j++) {
        var el = document.getElementById('orig'+i+'.'+j);
        if(el) {
          el.innerHTML = orig[i][j];
        }
      }
    }
window.location.hash = "";
updateGraph();
return true;
}

function showpg(group, num)
{
  document.body.ondblclick=showpgorig;
  var i;
  var j;
  if(orig.length==0) {
    for(i=0;i<wts.length;i++) {
      orig[i] = new Array();
      for(j=0;j<wts[i].length;j++) {
        var el = document.getElementById('orig'+i+'.'+j);
        if(el) {
          orig[i][j] = el.innerHTML;
        }
      }
    }
  }
  for(i=0;i<wts[group][num].length;i++) {
    if(wts[group][num][i]) {
      document.getElementById('par'+group+'.'+i).innerHTML = wts[group][num][i];
    }
//alert(wts[group,num,i]);
  }
  //temp=this.innerHTML; this.innerHTML=wts[$,,];
}

if (String(top.location).substring(0, 13) == 'http://shuhai' && top.location == self.location) { top.location = "http://shuhai.dsturgeon.net"; }


function showDic(el)
{
  var datanode = el.parentNode.parentNode.childNodes[1];
  var data = (datanode.textContent || datanode.innerText);
  document.getElementById('char').value = data;
  document.getElementById('dicform').submit();
}

function confirmexit()
{
  return "Your changes have not yet been saved. Are you sure you wish to abandon changes?";
}

var origdata = null;

function applyregex()
{
  var from = new RegExp(document.getElementById('regexfrom').value, "gm");
  var to = document.getElementById('regexto').value;
  var doc = document.getElementById('data').value;
//  var fix = ;
  to = to.replace(new RegExp("\\\\n", "gm"), "\r\n");
//  to = to.replace(new RegExp("([^\\\\])\\\\n", "gm"), ">$1<\r\n");

  if(origdata===null) {
    origdata = doc;
    document.getElementById('revertbutton').disabled = false;
  }
  var hits = doc.match(from);
  var hitcount = 0;
  if(hits) {
    hitcount = hits.length;
  }
  doc = doc.replace(from, to);
  document.getElementById('data').value = doc;
  document.getElementById('regexsavestatus').innerHTML = " Replaced " + hitcount + " matches.";
  window.onbeforeunload = confirmexit;
}

function revertregex()
{
  document.getElementById('data').value = origdata;
}

function getIf()
{
  var iflang = 'en';
  if(document.URL.match('if=gb')) {
    iflang = 'zh';
  }
  if(document.URL.match('remap=gb')) {
    iflang = iflang+'s';
  }
  return iflang;
}

function updateRegexSaved()
{
  if(request.readyState == 4) {
    if(request.status == 200) {
      var iflang = getIf();
      if(iflang=='gb') {
        document.getElementById('regexsavestatus').innerHTML = " 已保存。";
      } else {
        document.getElementById('regexsavestatus').innerHTML = " Saved.";
      }
    }
  }
}

function saveregex()
{
  var from = document.getElementById('regexfrom').value;
  var to = document.getElementById('regexto').value;
  var name = document.getElementById('regexname').value;

  var url = "saveregex.pl";
  request.open("POST", url, true);
  request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
  request.onreadystatechange = updateRegexSaved;
  var iflang = document.getElementById("toolboxif").value;
  request.send("from=" + encodeURIComponent(from) + "&to=" + encodeURIComponent(to) + "&name=" + encodeURIComponent(name));
}

function regexpreview()
{
//  var opened = window.open("");
  var fulldata = "";

  var from = new RegExp(document.getElementById('regexfrom').value, "gm");
  var to = document.getElementById('regexto').value;
  var doc = document.getElementById('data').value;
  doc = doc.replace(new RegExp('\r',"gm"), '\n');
var markerleft = '႙';
  var docdel = doc.replace(from, markerleft+'span class="diffdel">$&</span>');
  docdel = docdel.replace(new RegExp('^[^\n'+markerleft+']*$',"gm"), '');
  docdel = docdel.replace(new RegExp('\n+',"gm"), '<br /><br />');
  docdel = docdel.replace(new RegExp(markerleft,"gm"), '<');

  var docadd = doc.replace(from, markerleft+'span class="diffadd">'+to+'</span>');
  docadd = docadd.replace(new RegExp('^[^\n'+markerleft+']*$',"gm"), '');
  docadd = docadd.replace(new RegExp('\\\\n',"gm"), '\n');
  docadd = docadd.replace(new RegExp('\n+',"gm"), '<br /><br />');
  docadd = docadd.replace(new RegExp(markerleft,"gm"), '<');

  var target = document.getElementById('regexpreview');
  var iflang = document.getElementById("toolboxif").value;
  if(iflang=='en') {
    fulldata = '<h3>Search and replace results preview:</h3><table class="restable"><tr><th class="colhead">From</th><th class="colhead">To</th></tr><tr><td class="resrow">'+docdel+'</td><td class="resrow">'+docadd+'</td></tr></table>';
  } else {
    fulldata = '<h3>檢索、全部取代結果預覽：</h3><table class="restable"><tr><th class="colhead">原本</th><th class="colhead">取代為</th></tr><tr><td class="resrow">'+docdel+'</td><td class="resrow">'+docadd+'</td></tr></table>';
  }
  target.innerHTML = fulldata;
}

function regexpreviewfull()
{
  var from = document.getElementById('regexfrom').value;
  var to = document.getElementById('regexto').value;
  var resid = document.getElementById('resid').value;
  var target = document.getElementById('regexpreview');
  var iflang = document.getElementById("toolboxif").value;

  var url = "regexfull.pl";
  request.open("POST", url, true);
  request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
  request.onreadystatechange = showRegexPreview;
  var iflang = document.getElementById("toolboxif").value;
  var data = "res=" + resid + "&from=" + encodeURIComponent(from) + "&to=" + encodeURIComponent(to) + "&if=" + iflang;
  request.send(data);
  target.innerHTML = "Please wait... 請稍候...";
}

function showRegexPreview()
{
  if(request.readyState == 4) {
    if(request.status == 200) {
      var target = document.getElementById('regexpreview');
      target.innerHTML = request.responseText;
    }
  }
}

function analyzeText()
{
  var target = document.getElementById('chapterlist');
  var doc = document.getElementById('data').value;
  var from = new RegExp("^\\*([^\\*\n]*?)[ ]*\n", "gm");
  var exp = '';
  var result = '';
  var chapternames = new Array();
  var chapterlengths = new Array();
  var i=0;
  var lastpos = 0;
  var cansubmit = true;
  var warnings = '';
  var iflang = document.getElementById('toolboxif').value + document.getElementById('toolboxremap').value;
  var disablesubmit = false;

  while ((result = from.exec(doc)) !== null) {
    chapternames[i] = result[1];
    if(i>0) {
      chapterlengths[i-1] = from.lastIndex-lastpos;
    } else {
      if(from.lastIndex-result[0].length != 0) {
        var extra = doc.substr(0,(from.lastIndex-result[0].length));
        extra = extra.replace(new RegExp("[ \n\t\r]*", "gm"), '');
        if(extra.length>0) {
          warnings = warnings + '<img src="warn.gif" /> '+extra.length+' characters before '+chapternames[i]+' will be deleted!<br />'+extra;
        }
      }
    }
    lastpos = from.lastIndex;
    i++;
  }
  if(i>0) {
    chapterlengths[i-1] = doc.length-lastpos;
  }
  if(chapternames.length>0) {
    if(iflang == 'gb') {
      exp = '<table class="restable"><tr><th class="colhead">序號</th><th class="colhead">單位名稱</th><th class="colhead">長度</th><th class="colhead">註釋</th></tr>';
    } else if(iflang == 'gbgb') {
      exp = '<table class="restable"><tr><th class="colhead">序号</th><th class="colhead">单位名称</th><th class="colhead">长度</th><th class="colhead">注释</th></tr>';
    } else {
      exp = '<table class="restable"><tr><th class="colhead">Sequence</th><th class="colhead">Section title</th><th class="colhead">Length</th><th class="colhead">Comments</th></tr>';
    }
    var lasttitle = '';
    for(i=0;i<chapternames.length;i++) {
      var comments = "";
      if(chapterlengths[i] < 300) {
        if(iflang == 'gb') {
          comments = comments+' <img src="warn.gif" /> 單位正文較短。';
        } else if(iflang == 'gbgb') {
          comments = comments+' <img src="warn.gif" /> 单位正文较短。';
        } else {
          comments = comments+' <img src="warn.gif" /> Unusually short section.';
        }
      }
      if(chapterlengths[i] > 100000) {
        if(iflang == 'gb') {
          comments = comments+' <img src="warn.gif" /> 此單位正文過長。請把正文分成適當的單位。';
        } else if(iflang == 'gbgb') {
          comments = comments+' <img src="warn.gif" /> 此单位正文过长。请把正文分成适当的单位。';
        } else {
          comments = comments+' <img src="warn.gif" /> This section is too long. Please divide it into shorter sections.';
        }
        disablesubmit=true;
      } else if(chapterlengths[i] > 30000) {
        if(iflang == 'gb') {
          comments = comments+' <img src="warn.gif" /> 單位正文較長。';
        } else if(iflang == 'gbgb') {
          comments = comments+' <img src="warn.gif" /> 单位正文较长。';
        } else {
          comments = comments+' <img src="warn.gif" /> Unusually long section.';
        }
      }
      if(chapternames[i] == '') {
        if(iflang == 'gb') {
          comments = comments+' <img src="warn.gif" /> 單位缺題。請補充該單位的標題，或移除單位號（*）。';
        } else if(iflang == 'gbgb') {
          comments = comments+' <img src="warn.gif" /> 单位缺题。请补充该单位的标题，或移除单位号（*）。';
        } else {
          comments = comments+' <img src="warn.gif" /> No section title. Please add a title or remove the section marker (*).';
        }
        disablesubmit=true;
      } else if(chapternames[i] == lasttitle) {
        if(iflang == 'gb') {
          comments = comments+' <img src="warn.gif" /> 單位標題與上一單位相同。';
        } else if(iflang == 'gbgb') {
          comments = comments+' <img src="warn.gif" /> 单位标题与上一单位相同。';
        } else {
          comments = comments+' <img src="warn.gif" /> Same as previous title.';
        }
      }
      lasttitle = chapternames[i];
      exp = exp + '<tr><th class="colhead2">' + (i+1) + '</th><th class="colhead2">' + chapternames[i] + "</th><td class=\"resrow\">" + chapterlengths[i] + "</td><td class=\"resrow\">" + comments + "</td></tr>";
    }
    exp = exp + '</table>';
  } else {
    if(iflang == 'gb') {
      exp = "<img src=\"warn.gif\" /> 尚未找到任何單位，因此正文全部會加到一個新單位。<br />總長度："+doc.length;
    } else if(iflang == 'gbgb') {
      exp = "<img src=\"warn.gif\" /> 尚未找到任何单位，因此正文全部会加到一个新单位。<br />总长度："+doc.length;
    } else {
      exp = "<img src=\"warn.gif\" /> No chapters detected - will add all text to a single section.<br />Total length: "+doc.length;
    }
    if(doc.length<50) {
      disablesubmit=true;
    }
  }
  var lines = doc.split(/[\n\r]+/);
  var i;
  var linetotal = 0;
  for(i=0;i<lines.length;i++) {
    if(lines[i].length>30 && lines[i].length<60) {
      linetotal ++;
    }
  }

  if(linetotal/i > 0.3) {
    if(iflang == 'gb') {
      warnings = warnings + "<img src=\"warn.gif\" /> <b>段落總數比較多。</b>若您提交的原典當中的部分分行號不表示分段，您可以嘗試<a href=\"#\" onclick=\"document.getElementById('regexfrom').value='\^[^　 ](.{27,40})\\\\n'; document.getElementById('regexto').value='$1'; document.getElementById('regexname').value='行改段'; applyregex(); return false;\">自動轉換</a>。";
    } else if(iflang == 'gbgb') {
      warnings = warnings + "<img src=\"warn.gif\" /> <b>段落总数比较多。</b>若您提交的原典当中的部分分行号不表示分段，您可以尝试<a href=\"#\" onclick=\"document.getElementById('regexfrom').value='\^[^　 ](.{27,40})\\\\n'; document.getElementById('regexto').value='$1'; document.getElementById('regexname').value='行改段'; applyregex(); return false;\">自动转换</a>。";
    } else {
      warnings = warnings + "<img src=\"warn.gif\" /> <b>Unusually many paragraph breaks.</b> If your text has unnecessary line-breaks, you may wish to try <a href=\"#\" onclick=\"document.getElementById('regexfrom').value='\^[^　 ](.{27,40})\\\\n'; document.getElementById('regexto').value='$1'; document.getElementById('regexname').value='Lines to paragraphs'; applyregex(); return false;\">automatically removing them</a>.";
    }
  }
  if(iflang == 'gb') {
    exp = "<h3>檢查結果</h3>"+exp;
  } else if(iflang == 'gbgb') {
    exp = "<h3>检查结果</h3>"+exp;
  } else {
    exp = "<h3>Analysis</h3>"+exp;
  }
  if(warnings != '') {
    exp = exp + '<div style="border: 1px solid; margin: 5px; padding: 5px; background: #EEEEEE;">' + warnings + '</div>';
  }
  target.innerHTML = exp;
  document.getElementById('createresource').disabled=disablesubmit;
}
function setscansize(newsize)
{
  var imgvar=document.getElementById('previmg');
  var canvas=document.getElementById('canvas');
  var cont=document.getElementById('scancont');
imgvar.ondragstart = function() { return false; };

    imgvar.style.width=newsize;
    canvas.style.width=newsize;
    cont.style.width=newsize;
//alert(imgvar.height);
//    cont.style.height=imgvar.height+'px';
//alert(imgvar.height);
  createCookie("imgsize", newsize, 365);
  drawbox();
}
function resizescan()
{
  var imgvar=document.getElementById('previmg');
  if(imgvar.style.width=="400px") {
    setscansize("800px");
  } else {
    setscansize("400px");
  }
/*

  var imgvar=document.getElementById('previmg');
  var canvas=document.getElementById('canvas');
  var cont=document.getElementById('scancont');

  if(imgvar.style.width=="400px") {
    imgvar.style.width="800px";
    canvas.style.width="800px";
    cont.style.width="800px";
//alert(imgvar.height);
    cont.style.height=imgvar.height+'px';
//    paper.setViewBox(0,0,400,500);
  } else {
    imgvar.style.width="400px";
    canvas.style.width="400px";
    cont.style.width="400px";
//alert(imgvar.height);
    cont.style.height=imgvar.height+'px';
//paper.setViewBox(0,0,800,1000);
  }
  drawbox();
  createCookie("imgsize", imgvar.style.width, 365);
*/
}

var dragging = 0;
var dragx = 0;
var dragy = 0;
var thisx = 0;
var thisy = 0;

function scanmousedown(e)
{
//alert(window.event.srcElement.nodeName);

if(window.event) {
  if(window.event.srcElement.nodeName=='shape') {
    return true;
  }
}
//alert(document.getElementById('content').scrollTop);


//  alert(relMouseCoords(e).x);
  dragx = relMouseCoords(e).x;
  dragy = relMouseCoords(e).y;
thisx = dragx;
thisy = dragy;
  if(!isNaN(dragx)) {
    dragging = 1;
  }
//alert(dragx+','+dragy);
}
function scanmousemove(e)
{

if(window.event) {
  if(window.event.srcElement.nodeName=='shape') {
//    return false;
  }
}
  if(dragging) {
    thisx = relMouseCoords(e).x;
    thisy = relMouseCoords(e).y;
    paper.clear();
    var r = paper.rect(Math.min(dragx,thisx), Math.min(dragy,thisy), Math.abs(thisx-dragx), Math.abs(thisy-dragy));
    r.attr("stroke", "#f00");
    r.attr("fill", "#f00");
    r.attr("fill-opacity", "0.4");
  }
}

function scanmouseup(e)
{
  if(dragging==1) {
    dragging = 0;
//    thisx = relMouseCoords(e).x;
//    thisy = relMouseCoords(e).y;
//alert(thisx+','+thisy+';'+dragx+','+dragy);

    if(!(thisx==dragx && thisy==dragy) && !isNaN(thisx)) {
//alert(document.getElementById('previmg').style.width);
      paper.clear();
      var r = paper.rect(Math.min(dragx,thisx), Math.min(dragy,thisy), Math.abs(thisx-dragx), Math.abs(thisy-dragy));
      r.attr("stroke", "#f00");
      r.attr("fill", "#f00");
      r.attr("fill-opacity", "0.2");
      if(document.getElementById('previmg').style.width=="400px") {
        thisx*=2;
        thisy*=2;
        dragx*=2;
        dragy*=2;
      }
      document.location.hash = "box("+Math.min(dragx,thisx)+","+Math.min(dragy,thisy)+","+Math.abs(thisx-dragx)+","+Math.abs(thisy-dragy)+")";
    }
    return false;
  }
}

function relMouseCoords(event){
  if(window.event) {

  if(dragging && window.event.srcElement.nodeName=='shape') {
    return {x:dragx+window.event.offsetX, y:dragy+window.event.offsetY};
  }

    return {x:window.event.offsetX, y:window.event.offsetY};
  }

    var totalOffsetX = 0;
    var totalOffsetY = 0;
    var canvasX = 0;
    var canvasY = 0;
    var currentElement = document.getElementById('previmg');

    do{
       totalOffsetX += currentElement.offsetLeft - currentElement.scrollLeft + currentElement.clientLeft;
       totalOffsetY += currentElement.offsetTop - currentElement.scrollTop + currentElement.clientTop;
    }
    while(currentElement = currentElement.offsetParent)

    canvasX = event.pageX - totalOffsetX;
    canvasY = event.pageY - totalOffsetY;
if(addyoffset) {
canvasY += document.getElementById('content').scrollTop;
}

    return {x:canvasX, y:canvasY}
}
//HTMLCanvasElement.prototype.relMouseCoords = relMouseCoords;


var paper = null;

function drawbox()
{
  var imgvar=document.getElementById('previmg');
  var box=decodeURIComponent(location.hash.substring(1));
  if(paper) {
    paper.clear();
    paper.setSize(imgvar.width,imgvar.height);
  } else {
    paper=Raphael('canvas', imgvar.width,imgvar.height);
  }

//  alert(imgvar.height);
  var patt=/box\(([0-9]+),([0-9]+),([0-9]+),([0-9]+)\)/; 
  var res=patt.exec(box);
//  alert(res[1]+';'+res[2]+';'+res[3]+';'+res[4]+';');
  if(res) {
    var r;
    if(imgvar.style.width=="400px") {
      r = paper.rect(res[1]/2,res[2]/2,res[3]/2,res[4]/2);
    } else {
      r = paper.rect(res[1],res[2],res[3],res[4]);
    }
    r.attr("stroke", "#f00");
    r.attr("fill", "#f00");
    r.attr("fill-opacity", "0.2");
  }

}
